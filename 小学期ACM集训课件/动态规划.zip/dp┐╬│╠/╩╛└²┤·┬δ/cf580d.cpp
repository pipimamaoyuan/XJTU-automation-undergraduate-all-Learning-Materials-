#include <bits/stdc++.h>
using namespace std;

int n, m, k;
long long satis[20];
long long ci[400][400];
long long dp[(1 << 18)][18];

int main() {
  scanf("%d%d%d", &n, &m, &k);
  for(int i = 0; i < n; i++) {
    scanf("%lld", &satis[i]);
  }
  for(int i = 0; i < k; i++) {
    int x, y;
    long long m;
    scanf("%d%d%lld", &x, &y, &m);
    ci[x - 1][y - 1] = m;
  }

  memset(dp, 0x9f, sizeof dp);

  for(int i = 0; i < n; i++) {
    dp[1 << i][i] = satis[i];
  }

  long long ma = - LLONG_MAX - 1;

  for(int i = 1; i < (1 << n); i++) {
    for(int j = 0; j < n; j++) {
      for(int k = 0; k < n; k++) {
        if(i & (1 << k)) continue;
        dp[i | (1 << k)][k] = max(dp[i | (1 << k)][k], dp[i][j] + ci[j][k] + satis[k]);
      }
      if(__builtin_popcount(i) == m) {
        ma = max(ma, dp[i][j]);
      }
    }
  }
  printf("%lld\n", ma);
  return 0;
}
