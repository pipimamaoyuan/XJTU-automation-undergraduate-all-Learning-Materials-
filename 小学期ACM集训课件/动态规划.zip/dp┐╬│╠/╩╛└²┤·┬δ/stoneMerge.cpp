#include <bits/stdc++.h>
using namespace std;

// n
// ci

long long arr[110];
long long f[110][110];
long long sum[110];

int main() {
  int n;
  scanf("%d", &n);
  for(int i = 0; i < n; i++) {
    scanf("%lld", &arr[i]);
  }

  memset(f, 0x3f, sizeof f);

  sum[0] = 0;
  for(int i = 0; i < n; i++) {
    sum[i + 1] = sum[i] + arr[i];
  }

  for(int i = 0; i < n; i++) {
    f[i][i + 1] = 0;
  }

  for(int l = 2; l <= n; l++) {
    for(int i = 0; i < n; i++) {
      for(int j = i + 2; j <= i + l; j++) {
        for(int k = i + 1; k < j; k++) {
          f[i][j] = min(f[i][j], f[i][k] + f[k][j] + sum[j] - sum[i]);
        }
      }
    }
  }
  printf("%lld\n", f[0][n]);
  return 0;
}
