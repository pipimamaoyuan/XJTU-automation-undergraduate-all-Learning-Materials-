#include <bits/stdc++.h>
using namespace std;

// N V
// ci
// vi
// ki

// 3 50
// 1 2 4
// 5 12 20
// 10 20 30

int cs[1010];
long long vs[1010];
long long f[1010];
int ks[1010];

inline int lowbit(int x) { return x & -x; }

int main() {
  int N, V;
  scanf("%d%d", &N, &V);
  for(int i = 1; i <= N; i++) {
    scanf("%d", &cs[i]);
  }
  for(int i = 1; i <= N; i++) {
    scanf("%lld", &vs[i]);
  }
  for(int i = 1; i <= N; i++) {
    scanf("%d", &ks[i]);
  }
  vector<pair<int, long long>> vp;
  for(int i = 1; i <= N; i++) {
    while(ks[i]) {
      int cnt = lowbit(ks[i]);
      vp.emplace_back(cnt * cs[i], cnt * vs[i]);
      ks[i] -= cnt;
    }
  }
  // f[0][v] default 0
  for(auto&& item: vp) {
    for(int v = V; v >= 0; v--) {
      if(v >= item.first) f[v] = max(f[v], f[v - item.first] + item.second);
    }
  }
  printf("%lld\n", f[V]);
  return 0;
}
