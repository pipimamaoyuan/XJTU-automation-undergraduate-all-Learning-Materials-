#include <bits/stdc++.h>
using namespace std;

// A
// B

// acbaed
// abcadf

char A[1010], B[1010];
int la, lb;
int f[1010][1010];

pair<int, int> from[1010][1010];

int main() {
  scanf("%s%s", A + 1, B + 1);
  la = strlen(A + 1), lb = strlen(B + 1);
  for(int i = 1; i <= la; i++) {
    for(int j = 1; j <= lb; j++) {
      if(A[i] == B[j]) {
        f[i][j] = f[i - 1][j - 1] + 1;
        from[i][j] = make_pair(i - 1, j - 1);
      } else {
        f[i][j] = max(f[i - 1][j], f[i][j - 1]);

        if(f[i - 1][j] > f[i][j - 1]) from[i][j] = make_pair(i - 1, j);
        else from[i][j] = make_pair(i, j - 1);
      }
    }
  }
  printf("%d\n", f[la][lb]);

  int curi = la, curj = lb;
  string lcs;
  while(curi || curj) {
    if(A[curi] == B[curj]) lcs.push_back(A[curi]);

    pair<int, int> p = from[curi][curj];
    curi = p.first; curj = p.second;
  }
  reverse(lcs.begin(), lcs.end());
  cout << lcs << endl;
  return 0;
}
