#include <bits/stdc++.h>
using namespace std;

// N V
// ci
// vi

// 3 5
// 1 2 4
// 5 12 20

int cs[1010];
long long vs[1010];
long long f[1010][1010];

int main() {
  int N, V;
  scanf("%d%d", &N, &V);
  for(int i = 1; i <= N; i++) {
    scanf("%d", &cs[i]);
  }
  for(int i = 1; i <= N; i++) {
    scanf("%lld", &vs[i]);
  }
  // f[0][v] default 0
  for(int i = 1; i <= N; i++) {
    for(int v = 0; v <= V; v++) {
      if(v >= cs[i]) f[i][v] = max(f[i - 1][v], f[i - 1][v - cs[i]] + vs[i]);
      else f[i][v] = f[i - 1][v];
    }
  }
  printf("%lld\n", f[N][V]);
  return 0;
}
