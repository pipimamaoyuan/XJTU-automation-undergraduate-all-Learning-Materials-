#include <bits/stdc++.h>
using namespace std;

// N V
// ci
// vi

// 3 5
// 1 2 4
// 5 12 20

int cs[1010];
long long vs[1010];
long long f[1010];

int main() {
  int N, V;
  scanf("%d%d", &N, &V);
  for(int i = 1; i <= N; i++) {
    scanf("%d", &cs[i]);
  }
  for(int i = 1; i <= N; i++) {
    scanf("%lld", &vs[i]);
  }
  // f[0][v] default 0
  for(int i = 1; i <= N; i++) {
    for(int v = V; v >= 0; v--) {
      if(v >= cs[i]) f[v] = max(f[v], f[v - cs[i]] + vs[i]);
    }
  }
  printf("%lld\n", f[V]);
  return 0;
}
