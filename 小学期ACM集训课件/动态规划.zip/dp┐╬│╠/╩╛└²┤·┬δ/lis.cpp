#include <bits/stdc++.h>
using namespace std;

// n
// a_i

// 16
// 0 8 4 12 2 10 6 14 1 9 5 13 3 11 7 15

long long f[100010];
int lisl = 0;

int main() {
  int n;
  scanf("%d", &n);
  for(int i = 0; i < n; i++) {
    long long x;
    scanf("%lld", &x);
    int fn = upper_bound(f, f + lisl, x) - f;
    f[fn] = x;
    lisl = max(lisl, fn + 1);
  }
  printf("%d\n", lisl);
  return 0;
}
