#include <bits/stdc++.h>
using namespace std;

int c[110];
long long p[110][110];
long long f[110][110][110];
const long long inf = 0x3f3f3f3f3f3f3f3f;

int main() {
  int n, m, k;
  scanf("%d%d%d", &n, &m, &k);
  for(int i = 1; i <= n; i++) {
    scanf("%d", &c[i]);
  }
  for(int i = 1; i <= n; i++) {
    for(int j = 1; j <= m; j++) {
      scanf("%lld", &p[i][j]);
      if(c[i]) {
        if(c[i] == j) p[i][j] = 0;
        else p[i][j] = inf;
      }
    }
  }
  memset(f, 0x3f, sizeof f);
  f[0][0][0] = 0;
  for(int i = 1; i <= n; i++) {
    for(int j = 1; j <= n; j++) {
      for(int k = 1; k <= m; k++) {
        for(int l = 0; l <= m; l++) {
          if(l == k) {
            f[i][j][k] = min(f[i][j][k], f[i - 1][j][l] + p[i][k]);
          } else {
            f[i][j][k] = min(f[i][j][k], f[i - 1][j - 1][l] + p[i][k]);
          }
        }
      }
    }
  }
  long long ret = inf;
  for(int i = 1; i <= m; i++) {
    ret = min(ret, f[n][k][i]);
  }
  if(ret == inf) printf("-1\n");
  else printf("%lld\n", ret);
  return 0;
}
