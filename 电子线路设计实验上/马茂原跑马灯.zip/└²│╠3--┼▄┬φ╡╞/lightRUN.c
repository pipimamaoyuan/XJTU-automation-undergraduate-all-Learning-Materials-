 #include<reg51.h>

#define uint unsigned int
#define uchar unsigned char
	
void delay()
{
	uint i,j;
	for(i=0;i<=200;i++) for(j=0;j<=200;j++);
}

void main()
{
	uchar temp=0x01; //0000 0001
	uchar count=0;
	uint k=0;

	while(1)
	{
		if(P1==0x00)
		
			k++;
		
		if(k==1)
		{
			P0=~(temp<<count);		//0000 0010 -&gt; 1111 1101 the secound light light up
		// count means the bits that the uchar has to move
		delay();
		count=count+2;
		if(count>=8) count=0;
		}
		if(k==2)
		{
            P0=~(temp<<count);		//0000 0010 -&gt; 1111 1101 the secound light light up
		// count means the bits that the uchar has to move
		delay();
		count=count+4;
		if(count>=8) count=0;
        }
		if(k==0|k>=3)
		{
		P0=~(temp<<count);		//0000 0010 -&gt; 1111 1101 the secound light light up
		// count means the bits that the uchar has to move
		delay();
		count++;
		if(count>=8) count=0;}
	}
	return;
}