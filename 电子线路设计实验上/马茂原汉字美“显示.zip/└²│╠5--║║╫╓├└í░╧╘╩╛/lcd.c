#include<reg51.h>
#include "lml.h"
#include "1.h"
#include "2.h"
#include "3.h"
#include "4.h"
#include "5.h"
#define LCD P0
#define uint unsigned int
#define uchar unsigned char
unsigned char a,i,j,k;
int b;
sbit CS1=P2^4;
sbit CS2=P2^3;
sbit RS=P2^2;
sbit RW=P2^1;
sbit EN=P2^0;
sbit BUSY=P0^0;
 void DelayMS(uint ms)//��ʱ
{
 uchar i;
 while(ms--)
 {
  for(i=0;i<120;i++); 
  }
}
checkbusy()
{ 
EN=1;
RW=1;
RS=0;
LCD=0XFF;
if(BUSY);
}
writecode(unsigned char dat) //д����
{
checkbusy();
EN=1;
RW=0;
RS=0;
LCD=dat;
EN=1;
EN=0;
}
writedata(unsigned char dat) //д����
{ 
checkbusy();
EN=1;
RW=0;
RS=1;
LCD=dat;
EN=1;
EN=0;
}
//��������
void LCDDisplay(unsigned char page,unsigned char lineaddress, unsigned char table[8][128])
{
for(i=0;i<8;i++)
{
if(lineaddress<0X80)
{
CS1=0;
CS2=0;
}
writecode(page+i);
writecode(lineaddress);
for(j=0;j<64;j++)
{
writedata(table[i][j]);
lineaddress+=1;
}
if(lineaddress>=0X80)
{
CS1=1;
CS2=0;
lineaddress=lineaddress-0X40;
}
writecode(page+i);
writecode(lineaddress);
for(j=64;j<128;j++)
{
writedata(table[i][j]);
lineaddress+=1;
}
if(lineaddress>=0X80)
{
lineaddress=lineaddress-0X40;
} 
}
}
void lcdinti()
{ 
writecode(0X3F);
writecode(0XC0);
writecode(0XB8);
writecode(0X40);
}
main()
{ 
lcdinti();
while(1)
{
LCDDisplay(0Xb8,0X40,&a4);
DelayMS(10);
LCDDisplay(0Xb8,0X40,&a1);
DelayMS(10);
LCDDisplay(0Xb8,0X40,&a2);
DelayMS(10);
LCDDisplay(0Xb8,0X40,&a3);
DelayMS(10);
LCDDisplay(0Xb8,0X40,&a6);
DelayMS(10);
LCDDisplay(0Xb8,0X40,&a5);
DelayMS(10);		
}
}