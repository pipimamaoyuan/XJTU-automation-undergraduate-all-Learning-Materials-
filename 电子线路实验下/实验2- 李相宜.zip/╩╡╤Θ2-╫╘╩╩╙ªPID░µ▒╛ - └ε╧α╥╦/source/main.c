#include "ADC.h"
#include "DAC.h"
#include "Delay.h"
#include "SYS_Init.h"
#include "Timer.h"
#include "led.h"
#include "lcd.h" 
#include "c8051f020.h"
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

float PIDcontroller(float error,float error_sum,float error_pre ,float kp,float ki,float kd);  //PID控制实现函数

uchar cure_data[2][1024];
uchar cure_data_flag = 0;
typedef struct
{
    unsigned char base[129];
    unsigned char front, rear;
	unsigned char number;

} Queue;

Queue points;

//初始化队列
void InintQueue(Queue *Q)
{
	memset(Q->base,0,129*sizeof(uchar));
    Q->front = Q->rear = 0;
	Q->number=0;
}

//PID控制实现函数
float PIDcontroller(float error,float error_sum,float error_pre ,float kp,float ki,float kd)
{                  
	float output; 
	
	//计算最终的输出
  output = kp*error + ki * error_sum + kd * (error - error_pre);   //计算最终的输出
	return output;
}

 

// Timers value
unsigned int  timer0_value;
unsigned int  timer1_value;
unsigned int  timer2_value;
unsigned int  timer3_value;
unsigned int  timer4_value;

// ADC & DAC variables
unsigned char channel;   // ADC 通道转换
unsigned int  vref;      // VREF
unsigned int  vtarget;   // VTARGET
unsigned int  vadc;      // ADC 取值
unsigned int  vadc_dec;  // ADC 取值
unsigned int  vdac;      // DAC 输出
unsigned int  vdac_dec;  // DAC 输出
unsigned char string[5];		//数字转换为字符串
unsigned int k=0;

//用户初始化代码
uchar code str0[]="mamaoyuan XJTU";
uchar code str1[]="experient2";
uchar code str2[]="2 set PID";
uchar code str3[]="1 start/2 stop";

//PID展示
uchar code str10[]="change Kp";
uchar code str11[]="Kp---";
uchar code str12[]="Ki:  ";
uchar code str13[]="Kd:  ";

uchar code str20[]="change Ki";
uchar code str21[]="Kp:  ";
uchar code str22[]="Ki---";
uchar code str23[]="Kd:  ";

uchar code str30[]="change Kd";
uchar code str31[]="Kp:  ";
uchar code str32[]="Ki:  ";
uchar code str33[]="D---";

//定义结构体 PID
typedef struct{
	int setpoint;	
	long sumerror;			
	float P;			
	float I;			
	float D;	
	int lasterror;	
	int preverror;
	int result;
}PID;

PID tmp_pid={0,0,0,0,0,0,0,0};

const unsigned char code blank[1024] = { /* 0X00,0X01,0X80,0X00,0X40,0X00, */
	
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
};

volatile int wave[128]={0};

unsigned int KEY_FLAG;


//用户初始化代码
void PID_init(PID* ptr)
{
	
	//初始化结构体ptr的值
	ptr->setpoint = 2800;
	ptr->sumerror = 0; 
	ptr->lasterror = 0;
	ptr->preverror = 0;	
	ptr->P = 1.000;                
	ptr->I = 0.025;                
	ptr->D = 0.040;   
	ptr->result = 0;                                      			
}

// PID控制函数
void PID_contrl(PID* ptr,int nowpoint){
	int tmp_error;
	int tmp_common;
	tmp_error = ptr->setpoint - nowpoint;	
	ptr->sumerror+=tmp_error;
	tmp_common=tmp_error-ptr->lasterror;
	ptr->result=PIDcontroller(tmp_error,ptr->sumerror,ptr->lasterror,ptr->P,ptr->I,ptr->D);
	ptr->preverror=ptr->lasterror;
	ptr->lasterror = tmp_error;		
}

//显示PID参数
void PID_display(){
			WriteStr(0, 0, str0);
			WriteStr(1, 0, str1);
			WriteStr(2, 0, str2);
			WriteStr(3, 0, str3);
}

//根据索引显示PID参数
void display_pid_parameter(int i){
	switch(i){
		case 0:
			// 显示PID参数
			WriteStr(0, 0, str10);
			WriteStr(1, 0, str11);
			WriteStr(2, 0, str12);
			WriteStr(3, 0, str13);
		  sprintf(string,"%.3f",tmp_pid.P);
		  WriteStr(1, 5, string);
			sprintf(string,"%.3f",tmp_pid.I);
			WriteStr(2, 5, string);
			sprintf(string,"%.3f",tmp_pid.D);
			WriteStr(3, 5, string);
			break;
		case 1:
			WriteStr(0, 0, str20);
			WriteStr(1, 0, str21);
			WriteStr(2, 0, str22);
			WriteStr(3, 0, str23);
		sprintf(string,"%.3f",tmp_pid.P);
		WriteStr(1, 5, string);
		sprintf(string,"%.3f",tmp_pid.I);
			WriteStr(2, 5, string);
		sprintf(string,"%.3f",tmp_pid.D);
			WriteStr(3, 5, string);
			break;
		case 2:
			WriteStr(0, 0, str30);
			WriteStr(1, 0, str31);
			WriteStr(2, 0, str32);
			WriteStr(3, 0, str33);
		sprintf(string,"%.3f",tmp_pid.P);
		WriteStr(1, 5, string);
		sprintf(string,"%.3f",tmp_pid.I);
			WriteStr(2, 5, string);
		sprintf(string,"%.3f",tmp_pid.D);
			WriteStr(3, 5, string);
			break;
	}
}


//定时器 1 初始化
void Timer1_Init_Main(void) {
    Enable_Timer1;       // 设定 IE 标志位 1，允许 Timer1 溢出中断请求
    Timer1_Set_Method1;  // 设置定时器 1 为方式 1 定时器功能
}

//定时器 1 中断服务函数
void Timer1_ISR(void) interrupt 3 {
    timer1_value++;

    TH1 = 0x00; // 重新初始化Timer0 高位寄存器
    TL1 = 0x00;
}

//设备初始化
void Device_Init(void) {
    SYS_Init();  // SYS 初始化
		LcdInit();   
		LedInit();
    Timer1_Init_Main();
    Timer3_Init_ADC0(SYSCLK / SAMPLERATE);  // TIMER3 初始化 

    INT_Init();  // INT 中断初始化

    ADC0_Init();     // ADC0 初始化
    ADC0_Enable(1);  // 使能 ADC0
    DAC0_Init();     // DAC 初始化

    Timer1_Start;  // 设定 TCON 中断标志位 6，定时器 1 开启

    timer1_value = 0;
    timer3_value = 0;

    channel  = 1;
    vref     = 5244;
    vtarget  = 2800;
    vadc     = 0x0000;
    vadc_dec = 0;
    vdac     = 0x0000;
    vdac_dec = 0;
}

void Do(void) {
    if ((timer1_value & 0x0007) == 0x0001) {     
        if (channel == 1) 	 {
            // 从 ADC0 AIN1 取得 10 位 16 进制数 vadc
            vadc = ADC_ValueReturn(channel);
            // 将 vadc 转化为 10 进制数进行计算
            vadc_dec = (unsigned long int)vadc * (unsigned long int)vref / 4096;
						
					//调用PID控制函数
					  PID_contrl(&tmp_pid,vadc_dec);
						vdac_dec=vadc_dec+tmp_pid.result;
						// 将 10 进制数 vdac_dec 转化为 16 进制数
            vdac = (unsigned long int)vdac_dec * 4096 / (unsigned long int)vref;
            // 从 ADC0 输出 10 位 16 进制数 vdac
            DAC0_Output(vdac);
					
					//调节目标霍尔电压值
					if(KEY_FLAG==1){
						tmp_pid.setpoint-=100;
						KEY_FLAG=0;}
					else{
						if(KEY_FLAG==2){
						tmp_pid.setpoint+=100;
						KEY_FLAG=0;}
          }
      }
		}
	}
	
void setPID(void){
	int k=0;
	while(k!=3){
		//显示PID参数
		display_pid_parameter(k);
		//显示数字
		my_LedDispNum(vadc_dec,tmp_pid.setpoint,vdac_dec);
		Delay_ms(30);
		//如果按键标志为 1
		if(KEY_FLAG==1){
			switch(k){
				case 0:tmp_pid.P-=0.1;break;
				case 1:tmp_pid.I-=0.001;break;
				case 2:tmp_pid.D-=0.001;break;
			}
			//重置按键标志
			KEY_FLAG=0;}
		//按键标志为2	
		if(KEY_FLAG==2){
			switch(k){
				case 0:tmp_pid.P+=0.1;break;
				case 1:tmp_pid.I+=0.001;break;
				case 2:tmp_pid.D+=0.001;break;
			}
			KEY_FLAG=0;}
		  Delay_ms(30);
				//按键标志为 3
		if(KEY_FLAG==3){
			Delay_ms(30);
			KEY_FLAG=0;
			k+=1;
		}
	}
	//重置 k=0
	k=0;
}
	

void EnQueue(Queue *Q, unsigned char rows)
{
	//如果队列满
    if ((Q->rear + 1) % 129 == Q->front)
    {
			//队列头指针后移
        Q->front = (Q->front + 1) % 129;
		Q->number-=1;
    }
    Q->base[Q->rear] = rows;
    Q->rear = (Q->rear + 1) % 129;
	Q->number+=1;
}

void draw_buffer(uchar *buffer,Queue *Q)
{
	uchar num=Q->number,index=Q->front,count=0;
	while(num--!=0)
	{
		buffer[(47-Q->base[index])*16+(count>>3)]|=0x80>>(count&0x07);
		index=(index+1)%129;//实现index逐次往队尾移一位
		++count;
	}
}

uchar scale(unsigned int vadc_dec){
	unsigned char level = 0;
	
	//根据 vadc_dec计算电平
	level = (unsigned char)((vadc_dec-2500)/40);
	return level;
}

int main(void) {
    int i=0,j=0,k=0;
	
	//初始化设备
		Device_Init();
	
	//初始化PID控制器
	  PID_init(&tmp_pid);
	
	//初始化按键标志为0
		KEY_FLAG=0;
	
	//初始化队列
		InintQueue(&points);	
		
    while (1) {
			
		//显示数字
		my_LedDispNum(vadc_dec,tmp_pid.setpoint,vdac_dec);
			
		//显示PID控制信息
		PID_display();
			
			//按键标志为 2
		if(KEY_FLAG==2){
			
			//清空LCD显示
			LcdClear();
			ImageShow(blank);
			
			//重置按键标志
			KEY_FLAG=0;
			
			//设置PID参数
			setPID();
		}
		
		
		if(KEY_FLAG==1){
		LcdClear();
		ImageShow(blank);
		KEY_FLAG=0;

		//当按键标志不等于3时
		while(KEY_FLAG!=3){
			
			//显示数字
			my_LedDispNum(vadc_dec,tmp_pid.setpoint,vdac_dec);
			
			Do();
			i+=1;
			
			//如果I等于5
			if(i == 5){
				
				//重置
				i = 0;
				
				//入队列
				EnQueue(&points,scale(vadc_dec));
				
				//清空缓冲器
				memset(cure_data[cure_data_flag],0,1024*sizeof(uchar));//刷新缓冲器，全部赋0
				draw_buffer(cure_data[cure_data_flag],&points);//将队列中的点绘制到缓冲区
				ScreenShow(cure_data[cure_data_flag],cure_data[!cure_data_flag]);//画点，利用2个缓冲区	
				cure_data_flag=!cure_data_flag;//缓冲区互换角色
			}
			}
		  //设置vdac=0
			vdac=0;
			
			//输出vdac到DAC0
			DAC0_Output(vdac);
			
			//重置按键标志
			KEY_FLAG=0;
			
			//初始化LCD
			LcdInit();
      }
    }
}

// 中断服务函数
void INT1_ISR(void) interrupt 2
{
	
	Delay_ms(20);
	
	//根据P5的值进行判断
	switch(P5){
		case 0xfb:
			
		//按键标志为1
      KEY_FLAG=1;
			break;		
		
		case 0xfd:
			
		//按键标志为2
			KEY_FLAG=2;
			break;
		
		case 0xfe:
			
		//按键标志为3
			KEY_FLAG=3;
			break;
	}
}

